import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getDevNotifications, shouldUseJsonStorage } from "@/lib/dev-request-store";
import { getInternalActor } from "@/lib/internal-access";

export async function GET() {
  if (!await getInternalActor()) return NextResponse.json({ error: "No autorizado." }, { status: 401 });
  try {
    if (shouldUseJsonStorage()) {
      const notifications = await getDevNotifications();
      const unread = notifications.filter((notification) => !notification.isRead);
      return NextResponse.json({ notifications: unread, unreadCount: unread.length });
    }

    const notifications = await prisma.notification.findMany({
      where: { isRead: false },
      orderBy: { createdAt: "desc" },
      select: {
        id: true,
        requestId: true,
        type: true,
        isRead: true,
        createdAt: true,
        request: { select: { requestNumber: true, requesterName: true } },
      },
    });
    return NextResponse.json({
      unreadCount: notifications.length,
      notifications: notifications.map((notification) => ({
        id: notification.id,
        requestId: notification.requestId,
        type: notification.type,
        requestNumber: notification.request.requestNumber ?? "Solicitud sin número",
        requesterName: notification.request.requesterName,
        isRead: notification.isRead,
        createdAt: notification.createdAt,
      })),
    });
  } catch (error) {
    console.error("Error fetching notifications:", error);
    return NextResponse.json({ error: "No fue posible obtener las notificaciones." }, { status: 500 });
  }
}