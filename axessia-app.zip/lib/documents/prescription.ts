import { prisma } from "@/lib/prisma";
import { deleteStoredFile, saveStoredFile } from "@/lib/storage/store-file";
import {
  validateUploadFile,
  type AllowedExtension,
  type AllowedMimeType,
} from "@/lib/storage/validation";

export type ValidatedPrescriptionUpload = {
  buffer: Buffer;
  fileName: string;
  mimeType: AllowedMimeType;
  extension: AllowedExtension;
};

export async function validatePrescriptionUpload(file: File): Promise<
  | { ok: true; value: ValidatedPrescriptionUpload }
  | { ok: false; error: string }
> {
  const buffer = Buffer.from(await file.arrayBuffer());
  const extension = file.name.split(".").pop() ?? "";
  const validation = validateUploadFile({
    buffer,
    mimeType: file.type,
    extension,
    size: buffer.length,
  });

  if (!validation.ok) {
    return { ok: false, error: validation.error };
  }

  return {
    ok: true,
    value: {
      buffer,
      fileName: file.name,
      mimeType: validation.mimeType,
      extension: validation.extension,
    },
  };
}

export async function savePrescriptionForRequest(input: {
  requestId: string;
  customerId: string | null;
  fileName: string;
  buffer: Buffer;
  mimeType: AllowedMimeType;
  extension: AllowedExtension;
}) {
  let storageKey: string | null = null;

  try {
    storageKey = await saveStoredFile("prescriptions", input.requestId, input.buffer, input.extension);

    return await prisma.prescription.create({
      data: {
        requestId: input.requestId,
        customerId: input.customerId,
        fileName: input.fileName,
        mimeType: input.mimeType,
        fileSize: input.buffer.length,
        storageKey,
      },
    });
  } catch (error) {
    if (storageKey) await deleteStoredFile(storageKey);
    throw error;
  }
}
